package co.com.k4soft.facturaciondejackeline.util;

public class Parametro {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "facturacion" ;
}
