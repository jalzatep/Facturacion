package co.com.k4soft.facturaciondejackeline.persistence.database;

public class Table {
    public static final String PRODUCTO ="producto";
}
